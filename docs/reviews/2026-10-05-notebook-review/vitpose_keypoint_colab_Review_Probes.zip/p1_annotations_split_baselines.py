"""P1: the COCO image host (images.cocodataset.org) is unreachable from the review container, so the photographs
cannot be re-fetched. The carried SAMPLE_IMAGES table holds every pinned person's box and joints, and
build_sample_dataset draws the split from image ids alone, so this probe rebuilds the 180/45/75 image split and its
person counts and categories from the table, and recomputes the two box-only baselines with the carried metrics.
Both baselines are scale-invariant (PCK radius is a fraction of the box side; the OKS scale is the box area), so the
native-resolution values should match the recorded degraded-input values up to the degradation's rounding and
box clipping."""
import json, sys, types, importlib
from collections import Counter
from pathlib import Path
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('vitpose_keypoint_pipeline'); pkg.__path__ = [str(repo / 'src/vitpose_keypoint_pipeline')]
sys.modules['vitpose_keypoint_pipeline'] = pkg
S = importlib.import_module('vitpose_keypoint_pipeline.samples')
M = importlib.import_module('vitpose_keypoint_pipeline.metrics')
records = []
for image_id, size, digest, w, h, lic, flickr, persons in S.SAMPLE_IMAGES:
    for entry in persons:
        ann, box, joints = S._parse_person(entry)
        records.append({'id': f'coco-{image_id}-{ann}', 'image_id': image_id, 'box': box, 'keypoints': joints, 'category': S.category_for(len(joints)), 'n_labelled': len(joints)})
splits = S.build_sample_dataset(records, seed=S.SAMPLE_SEED)
res = {'pinned_images': len(S.SAMPLE_IMAGES), 'pinned_persons': len(records), 'pinned_bytes': sum(r[1] for r in S.SAMPLE_IMAGES),
       'constants': {'CORPUS_IMAGES': S.CORPUS_IMAGES, 'CORPUS_PERSONS': S.CORPUS_PERSONS, 'CORPUS_BYTES': S.CORPUS_BYTES},
       'licence_ids': dict(Counter(r[5] for r in S.SAMPLE_IMAGES)),
       'split_images': {k: len({r['image_id'] for r in v}) for k, v in splits.items()},
       'split_persons': {k: len(v) for k, v in splits.items()},
       'image_overlap_between_splits': len(set.intersection(*[{r['image_id'] for r in v} for v in splits.values()])),
       'test_categories': dict(Counter(r['category'] for r in splits['test'])),
       'min_labelled': min(r['n_labelled'] for r in records)}
bc = M.box_centre_baseline(splits['test']); mp = M.mean_pose_baseline(splits['train'], splits['test'])
r3 = lambda d: {k: round(d[k], 3) for k in ('pck', 'oks')}
res['box_centre_native'] = r3(bc); res['mean_pose_native'] = r3(mp)
res['mean_pose_per_category_native'] = {c: r3(v) for c, v in mp['per_category'].items()}
res['record_2026_09_20_degraded'] = {'box_centre': {'pck': 0.086, 'oks': 0.165}, 'mean_pose': {'pck': 0.472, 'oks': 0.44},
    'test_categories': {'full': 38, 'partial': 47, 'sparse': 51}, 'frozen_small_pck': 0.598, 'frozen_small_oks': 0.564}
print(json.dumps(res, indent=1)); (out / 'p1.json').write_text(json.dumps(res, indent=1))
