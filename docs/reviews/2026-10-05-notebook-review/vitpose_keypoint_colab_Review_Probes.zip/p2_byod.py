"""P2: the BYOD branch of cell 13 exec'd with a google.colab stand-in on constructed zips (synthetic photographs,
one or more person boxes each, 17 labelled joints), through split_dataset and the per-split validate_dataset the
cell runs next. Sweeps persons x images to find the smallest set the cell accepts, against the stated 'at least
eight persons'. Also: missing image, too few joints, joint outside the image, cancelled dialog, outside Colab."""
import io, json, sys, types, zipfile, importlib, os, contextlib
from pathlib import Path
import numpy as np
from PIL import Image
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('vitpose_keypoint_pipeline'); pkg.__path__ = [str(repo / 'src/vitpose_keypoint_pipeline')]
sys.modules['vitpose_keypoint_pipeline'] = pkg
S = importlib.import_module('vitpose_keypoint_pipeline.samples')
P = importlib.import_module('vitpose_keypoint_pipeline.pipeline')
NAMES = P.KEYPOINT_NAMES
rng = np.random.default_rng(0)
def png(seed):
    b = io.BytesIO(); Image.fromarray(np.random.default_rng(seed).integers(0, 255, (200, 300, 3), dtype=np.uint8)).save(b, 'PNG'); return b.getvalue()
def build(n_images, per_image, drop_joints=0, bad_joint=False, missing_image=False):
    header = ['file', 'person', 'x0', 'y0', 'x1', 'y1'] + [f'{j}_{a}' for j in NAMES for a in ('x', 'y')]
    rows, members = [','.join(header)], {}
    for i in range(n_images):
        members[f'img{i}.png'] = png(i)
        for p in range(per_image):
            x0 = 5 + (280 // max(per_image, 1)) * p; wbox = max(20, 280 // max(per_image, 1) - 5); vals = [f'img{i}.png', str(p), str(x0), '20', str(x0 + wbox), '180']
            for k, j in enumerate(NAMES):
                if k < drop_joints: vals += ['', '']
                else: vals += [str(x0 + 2 + (k % 5) * max(1, wbox // 6)), str(30 + k * 8)]
            if bad_joint and i == 0 and p == 0: vals[6] = '999'
            rows.append(','.join(vals))
    members['keypoints.csv'] = ('\n'.join(rows) + '\n').encode()
    if missing_image: members.pop('img0.png')
    return members
nb = json.loads((repo / 'tutorials/vitpose_keypoint_colab.ipynb').read_text())
c13 = next(''.join(c['source']) for c in nb['cells'] if 'USE_BYOD = False' in ''.join(c['source']))
branch = '\n'.join(l[4:] for l in c13.split('if USE_BYOD:\n', 1)[1].split('\nelse:', 1)[0].splitlines())
tail = c13.split("dataset_manifests = ", 1)[1].split('\ndisjoint', 1)[0]
code = branch + '\ndataset_manifests = ' + tail + '\n'
os.chdir(out)
def run(uploaded):
    colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda: dict(uploaded))
    sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    g = {'Path': Path, 'load_byod_dataset': S.load_byod_dataset, 'split_dataset': S.split_dataset, 'validate_dataset': S.validate_dataset, 'SPLIT_SEED': 42}
    try:
        exec(code, g)
        return {'outcome': 'accepted', 'split_persons': {k: m['n_records'] for k, m in g['dataset_manifests'].items()}}
    except BaseException as exc:
        return {'outcome': 'refused', 'error': f'{type(exc).__name__}: {exc}'[:200]}
def z(members):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as zf:
        for k, v in members.items(): zf.writestr(k, v)
    return {'byod.zip': b.getvalue()}
res = {'stated_minimum': 'at least eight persons (cell 0); a dataset needs 8..5,000 records (cell 1)', 'sweep': {}}
for n_images, per in [(1, 8), (2, 4), (4, 2), (8, 1), (4, 4), (4, 8), (8, 2), (8, 3), (12, 2), (20, 2), (40, 1), (52, 1), (53, 1), (60, 1)]:
    res['sweep'][f'{n_images}img_x_{per}persons={n_images * per}'] = run(z(build(n_images, per)))
res['loader_cases'] = {
    'missing_image': run(z(build(60, 1, missing_image=True))),
    'too_few_joints_(11)': run(z(build(60, 1, drop_joints=6))),
    'joint_outside_image': run(z(build(60, 1, bad_joint=True))),
    'cancelled_dialog': run({}),
}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
try:
    exec('from google.colab import files', {}); res['outside_colab'] = 'no error'
except Exception as exc:
    res['outside_colab'] = f'{type(exc).__name__}: {exc}'
res['byod_cell_has_path_field'] = 'BYOD_PATH' in c13
print(json.dumps(res, indent=1)); (out / 'p2.json').write_text(json.dumps(res, indent=1))
